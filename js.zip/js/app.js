/* small placeholder JS - currently pages are static and navigation via links */
/* In future this will hold Firebase auth and API calls */
console.log('Legxi-AI UI loaded');
